//
//  ZLCollectionBackView.h
//  ZLCollectionView
//
//  Created by zhaoliang chen on 2020/4/17.
//  Copyright © 2020 zhaoliang chen. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZLCollectionBaseDecorationView : UICollectionReusableView

@end

NS_ASSUME_NONNULL_END
