//
//  ZLCollectionReusableView.h
//  ZLCollectionView
//
//  Created by zhaoliang chen on 2018/7/9.
//  Copyright © 2018年 zhaoliang chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZLCollectionReusableView : UICollectionReusableView

@end
