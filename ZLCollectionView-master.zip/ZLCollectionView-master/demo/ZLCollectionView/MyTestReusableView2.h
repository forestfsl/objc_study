//
//  MyTestReusableView2.h
//  ZLCollectionView
//
//  Created by zhaoliang chen on 2019/1/9.
//  Copyright © 2019 zhaoliang chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZLCollectionBaseDecorationView.h"

NS_ASSUME_NONNULL_BEGIN

@interface MyTestReusableView2 : ZLCollectionBaseDecorationView

- (void)updateImageView:(NSString*)url;

@end

NS_ASSUME_NONNULL_END
