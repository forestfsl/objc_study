//
//  MyTestReusableView.h
//  ZLCollectionView
//
//  Created by zhaoliang chen on 2018/7/11.
//  Copyright © 2018年 zhaoliang chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZLCollectionReusableView.h"

@interface MyTestReusableView : UICollectionReusableView

- (void)updateImageView;

@end
	
